# CodeAlpha Task 1 — Iris Flower Classification

## Objective
Classify Iris flowers into Setosa, Versicolor and Virginica using four flower measurements.

## Dataset
`Iris.csv` — 150 records.

## Features
- SepalLengthCm
- SepalWidthCm
- PetalLengthCm
- PetalWidthCm

## Machine Learning Model
Logistic Regression with StandardScaler.

## Evaluation
- Test size: 20%
- Random state: 42
- Accuracy: 93.33%

## Included Files
- Task_1_Iris_Flower_Classification.ipynb
- Iris.csv
- confusion_matrix.png
- iris_species_distribution.png
- README.md

## Installation
```bash
pip install pandas numpy matplotlib seaborn scikit-learn jupyter
```

Open the notebook and run all cells.
